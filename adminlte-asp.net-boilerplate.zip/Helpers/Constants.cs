﻿namespace FundedMillionaires.Web.Mvc.Helpers
{
    public class Constants
    {
        public const string MSG_SUCCESS = "SUCCESS";
        public const string MSG_ERROR = "ERROR";
        
        public const int SC_SUCCESS = 200;
        public const int SC_BADREQ = 400;
        public const int SC_UNAUTH = 401;
        public const int SC_FORBIDDEN = 403;
        public const int SC_ISE = 500;

        public const string MSG_NO_TOKEN = "Empty Token";
        public const string MSG_INV_TOKEN = "Invalid Token";
        public const string MSG_INV_CRED = "Invalid Credentials";
        public const string MSG_EMPTY_INPUT = "One or more inputs are empty or the model is empty";
        public const string MSG_ISE = "Application error occured.";

        public const int STM_CREDIT = 1;
        public const int STM_DEBIT = 0;
    }
}
