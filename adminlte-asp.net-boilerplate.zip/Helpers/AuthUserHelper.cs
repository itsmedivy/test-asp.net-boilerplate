﻿using System.Security.Claims;

namespace FundedMillionaires.Web.Mvc.Helpers
{
    public class AuthUserHelper
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        public AuthUserHelper(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public string UserFullName()
        {
            return "Admin";
        }

        public string RowId()
        {
            return "GUID";
        }
        public int UserId()
        {
            return 1;
        }
    }
}
