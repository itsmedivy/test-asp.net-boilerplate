﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace FundedMillionaires.Web.Mvc.Helpers
{
    public static class HtmlHelper
    {
        const string MATERIAL_BG_COLORS = "#C62828,#AD1457,#6A1B9A,#4527A0,#283593,#1565C0,#0277BD,#00838F,#00695C,#2E7D32,#558B2F,#9E9D24,#F9A825,#FF8F00,#EF6C00,#D84315,#4E342E,#424242,#37474F";
        #region Design Perspective
        public static string IsSelected(this IHtmlHelper html, string controller = null, string action = null, string cssClass = null)
        {
            if (String.IsNullOrEmpty(cssClass))
                cssClass = "active";

            string currentAction = (string)html.ViewContext.RouteData.Values["action"];
            string currentController = (string)html.ViewContext.RouteData.Values["controller"];

            if (String.IsNullOrEmpty(controller))
                controller = currentController;

            if (String.IsNullOrEmpty(action))
                action = currentAction;

            return controller == currentController && action == currentAction ?
                cssClass : String.Empty;
        }
        public static string PageClass(this IHtmlHelper htmlHelper)
        {
            string currentAction = (string)htmlHelper.ViewContext.RouteData.Values["action"];
            return currentAction;
        }
        public static HtmlString TransactionMode(this IHtmlHelper html, int mode)
        {
            string str_html = "";
            if (mode == Constants.STM_CREDIT)
                str_html = "<span class='label label-success'>Cr</span>";
            else
                str_html = "<span class='label label-danger'>Db</span>";
            return new HtmlString(str_html);
        }
        public static HtmlString GenerateAlert(this IHtmlHelper html, string CssClass, string Title, string Message)
        {
            HtmlString ihtml = null;
            ihtml = Bootstrap.Alert(CssClass, Title, Message);
            return ihtml;
        }
        public static HtmlString GenerateBreadcrumb(this IHtmlHelper html, string Parent, string Title)
        {
            string str_html = "";
            str_html += " <h1>" + Title + "</h1>";
            str_html += "        <ol class='breadcrumb'>";
            str_html += "            <li>";
            str_html += "                <a href='/Dashboard/Index'>Dashboard</a>";
            str_html += "            </li>";
            str_html += "            <li>";
            str_html += "                <a>" + Parent + "</a>";
            str_html += "            </li>";
            str_html += "            <li class='active'>";
            str_html += "                <strong>" + Title + "</strong>";
            str_html += "            </li>";
            str_html += "        </ol>";
            return new HtmlString(str_html);
        }
        public static HtmlString CircleNameInitials(this IHtmlHelper htmlHelper, string Name)
        {
            // Extracting initials from full name
            string[] nameParts = Name.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            string initials = "";
            string color = GetRandomColor();
            if (nameParts.Length > 0)
            {
                initials += char.ToUpper(nameParts[0][0]);
                if (nameParts.Length > 1)
                {
                    initials += char.ToUpper(nameParts[nameParts.Length - 1][0]);
                }
            }
            string str_html = $"<span class='icircle' style='background:{color}'>{initials}</span>";
            return new HtmlString(str_html);
        }
        private static string GetRandomColor()
        {
            string hexValues = MATERIAL_BG_COLORS;
            // Split the string into an array of individual hexadecimal values
            string[] colors = hexValues.Split(',');
            // Generate a random index to select a random color
            Random random = new Random();
            int index = random.Next(0, colors.Length);
            // Return the randomly selected color
            return colors[index];
        }
        #endregion

        #region Data Converters
        public static string Date(this IHtmlHelper htmlHelper, DateTime date, string format = "dd-MMM-yyyy")
        {
            return string.Format("{0:" + format + "}", date);
        }
        public static string PrefixDouble(this IHtmlHelper htmlHelper, string _prefix, double DValue)
        {
            return $"{_prefix}{DValue:0.###}";
            //return $"{_prefix}{string.Format("{0:0.000}", DValue)}";
        }
        public static string SuffixDouble(this IHtmlHelper htmlHelper, string _suffix, double DValue)
        {
            return $"{DValue:0.###}{_suffix}";
            //return $"{string.Format("{0:0.000}", DValue)}{_suffix}";
        }

        public static string Money(this IHtmlHelper htmlHelper, string Currency, double Amount)
        {
            return $"{Currency}{Amount:0.###}";
            //return $"{Currency}{string.Format("{0:0.000}", Amount)}";
        }
        public static string Money(this IHtmlHelper htmlHelper, double Amount)
        {
            return $"{Amount:0.###}";
            //return $"{string.Format("{0:0.000}", Amount)}";
        }
        public static string NumberWords(this IHtmlHelper htmlHelper, double number)
        {
            return NumberUtility.ConvertAmount(number);
        }
        #endregion
    }

    public enum BS_Alert
    {
        Success,
        Warning,
        Danger,
        Info
    }
    public enum BS_ProgressSize
    {
        SM, XS, XXS
    }
    public static class Bootstrap
    {
        public static HtmlString Progress(decimal Percentage, BS_ProgressSize size = BS_ProgressSize.XS)
        {
            string ihtml = "", cssClass = "";
            Percentage = Math.Round(Percentage);

            if (Percentage <= 0)
                Percentage = (decimal)0.9;

            if (Percentage >= 0 && Percentage <= 20)
                cssClass = "danger";
            else if (Percentage >= 21 && Percentage <= 40)
                cssClass = "warning";
            else if (Percentage >= 41 && Percentage <= 60)
                cssClass = "info";
            else if (Percentage >= 61 && Percentage <= 80)
                cssClass = "primary";
            else if (Percentage >= 81 && Percentage <= 100)
                cssClass = "success";

            ihtml += "<div class=\"progress progress-" + size.ToString().ToLower() + " progress-striped active\">" + Environment.NewLine;
            ihtml += "    <div class=\"progress-bar progress-bar-" + cssClass + "\" style=\"width:" + Percentage + "%\"></div>" + Environment.NewLine;
            ihtml += "</div>";

            HtmlString html = new HtmlString(ihtml);
            return html;
        }
        public static HtmlString Alert(BS_Alert alert, string Title, string Message, List<HtmlString> prevAlerts = null)
        {
            HtmlString html = Alert(alert.ToString().ToLower(), Title, Message, prevAlerts);
            return html;
        }

        public static HtmlString Alert(string CssClass, string Title, string Message, List<HtmlString> prevAlerts = null)
        {
            string ihtml = "", icon = "";
            switch (CssClass)
            {
                case "danger":
                    icon = "<i class=\"icon fa-solid fa-circle-xmark fa-shake\"></i>";
                    break;
                case "warning":
                    icon = "<i class=\"icon fa-solid fa-circle-radiation fa-spin\"></i>";
                    break;
                case "info":
                    icon = "<i class=\"icon fa-solid fa-circle-info fa-bounce\"></i>";
                    break;
                case "success":
                    icon = "<i class=\"icon fa-solid fa-circle-check fa-beat\"></i>";
                    break;
                default:
                    icon = "<i class=\"icon fa-solid fa-shapes fa-flip\"></i>";
                    break;
            }
            ihtml += "<div class=\"alert alert-" + CssClass + " alert-dismissible\">" + Environment.NewLine;
            ihtml += "   <button type=\"button\" class=\"close\" data-dismiss=\"alert\">&times;</button>" + Environment.NewLine;
            ihtml += "   <h4>" + icon + "&nbsp;" + Title + "</h4>" + Environment.NewLine;
            ihtml += "   " + Message + Environment.NewLine;
            ihtml += "</div>";
            if (prevAlerts != null && prevAlerts.Count > 0)
            {
                foreach (var item in prevAlerts)
                    ihtml = ihtml + item.ToString();
            }
            HtmlString html = new HtmlString(ihtml);
            return html;
        }

        public static HtmlString ShowAlerts(List<HtmlString> prevAlerts)
        {
            string ihtml = "";
            if (prevAlerts != null && prevAlerts.Count > 0)
            {
                foreach (var item in prevAlerts)
                    ihtml = ihtml + item.ToString();
            }
            return new HtmlString(ihtml);
        }
    }
    public class NumberUtility
    {
        private static String[] units = { "Zero", "One", "Two", "Three",
            "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven",
            "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen",
            "Seventeen", "Eighteen", "Nineteen" };
        private static String[] tens = { "", "", "Twenty", "Thirty", "Forty",
            "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };

        public static String ConvertAmount(double amount)
        {
            try
            {
                Int64 amount_int = (Int64)amount;
                Int64 amount_dec = (Int64)Math.Round((amount - (double)(amount_int)) * 100);
                if (amount_dec == 0)
                {
                    return Convert(amount_int) + " Only.";
                }
                else
                {
                    return Convert(amount_int) + " Point " + Convert(amount_dec) + " Only.";
                }
            }
            catch (Exception e)
            {
                // TODO: handle exception  
            }
            return "";
        }

        private static String Convert(Int64 i)
        {
            if (i < 20)
            {
                return units[i];
            }
            if (i < 100)
            {
                return tens[i / 10] + ((i % 10 > 0) ? " " + Convert(i % 10) : "");
            }
            if (i < 1000)
            {
                return units[i / 100] + " Hundred"
                        + ((i % 100 > 0) ? " And " + Convert(i % 100) : "");
            }
            if (i < 100000)
            {
                return Convert(i / 1000) + " Thousand "
                        + ((i % 1000 > 0) ? " " + Convert(i % 1000) : "");
            }
            if (i < 10000000)
            {
                return Convert(i / 100000) + " Lakh "
                        + ((i % 100000 > 0) ? " " + Convert(i % 100000) : "");
            }
            if (i < 1000000000)
            {
                return Convert(i / 10000000) + " Crore "
                        + ((i % 10000000 > 0) ? " " + Convert(i % 10000000) : "");
            }
            return Convert(i / 1000000000) + " Arab "
                    + ((i % 1000000000 > 0) ? " " + Convert(i % 1000000000) : "");
        }
    }
}
