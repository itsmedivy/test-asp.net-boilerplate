﻿using FundedMillionaires.Web.Mvc.Models;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.Extensions.Options;

namespace FundedMillionaires.Web.Mvc.Helpers
{
    public class AppTitleHelper
    {
        private readonly AppSettingModel _setting;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public AppTitleHelper(IOptions<AppSettingModel> options, IHttpContextAccessor httpContextAccessor)
        {
            _setting = options.Value;
            _httpContextAccessor = httpContextAccessor;
        }

        public string GetPageTitle(ViewDataDictionary viewData)
        {
            string appName = _setting.AppName;
            string appVersion = _setting.AppVersion;
            string pageTitle = viewData["Title"]?.ToString();
            string currentPage = pageTitle ?? _httpContextAccessor.HttpContext.Request.Path;

            return $"{currentPage} - {appName} v{appVersion}";
        }

        public string GetAppName()
        {
            return _setting.AppName;
        }
        public string GetAppVersion()
        {
            return _setting.AppVersion;
        }
    }
}
