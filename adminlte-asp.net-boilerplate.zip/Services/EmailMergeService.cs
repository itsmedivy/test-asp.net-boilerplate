﻿namespace FundedMillionaires.Web.Mvc.Services
{
    public class EmailMergeService
    {
        public EmailMergeService()
        {
            
        }
    }
}
