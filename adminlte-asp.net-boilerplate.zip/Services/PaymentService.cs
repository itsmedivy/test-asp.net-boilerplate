﻿using FundedMillionaires.Web.Mvc.Models;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using Stripe;
using Stripe.Checkout;

namespace FundedMillionaires.Web.Mvc.Services
{
    public class PaymentService
    {
        private readonly ILogger<PaymentService> _logger;
        private readonly AppSettingModel _setting;
        private readonly StripeSetting stripeSetting;
        public PaymentService(ILogger<PaymentService> logger, IOptions<AppSettingModel> options)
        {
            _logger = logger;
            _setting = options.Value;
            stripeSetting = _setting.StripeSettings;
        }
        public PayResponseModel Pay(PayModel model)
        {
            string successUrl = stripeSetting.SuccessURL;
            string cancelUrl = stripeSetting.CancelURL;
            StripeConfiguration.ApiKey = stripeSetting.SecretKey;

            Log.Information("------ Process: Stripe Payment Init Started --------");

            var options = new SessionCreateOptions
            {
                PaymentMethodTypes = new List<string>
                {
                    "card"
                },
                ClientReferenceId = model.ClientRefId,
                CustomerEmail = model.Email,
                LineItems = new List<SessionLineItemOptions>
                {
                    new SessionLineItemOptions
                    {
                        Price = model.ProductPriceId,
                        Quantity = 1,
                    }
                },
                Mode = "payment",
                SuccessUrl = successUrl,
                CancelUrl = cancelUrl,
            };
            Log.Information("------ Payment request payload prepared --------");
            string json = JsonConvert.SerializeObject(options);
            Log.Information(json);
            Log.Information("------ Sending Payment request payload to Stripe --------");
            var service = new SessionService();
            var session = service.Create(options);

            PayResponseModel resp = new PayResponseModel
            {
                SessionId = session.Id,
                StripeUrl = session.Url
            };
            Log.Information("------ Process: Stripe Payment Init Ended --------");
            return resp;
        }

        public PayResponseModel GetSession(string Id)
        {
            Log.Information("------ Process: Returned from Stripe Started--------");
            if (!string.IsNullOrEmpty(Id))
            {
                var service = new SessionService();
                Session session = service.Get(Id);
                Log.Information("------ Fetched Stripe Payment Session Details (" + Id + ") --------");
                if (session != null)
                {
                    string json = session.ToJson();
                    Log.Information(json);
                    Log.Information("------ Process: Returned from Stripe Ended --------");
                    return new PayResponseModel()
                    {
                        SessionId = session.Id,
                        StripeUrl = session.Url,
                        ClientRefId = session.ClientReferenceId,
                        CustomerEmail = session.CustomerEmail,
                        Status = session.Status, //open,complete,expired
                        PaymentStatus = session.PaymentStatus, //paid,un_paid,no_payment_required
                        Amount = session.AmountTotal,
                        CurrencyCode = session.Currency
                    };
                }
            }
            Log.Information("------ Process: Returned from Stripe Ended --------");
            return null;
        }

        public int GetPrice(string PriceId)
        {
            int amount = 0;
            StripeConfiguration.ApiKey = stripeSetting.SecretKey;
            var service = new PriceService();
            Price _price = service.Get("price_1PNEpr016cnQWqmwvfMjSsYo");
            if (_price != null)
            {
                if (_price.BillingScheme == "per_unit")
                {
                    var l_amount = _price.UnitAmount ?? 0;
                    amount = (int)l_amount;
                }
            }
            return amount;
        }
    }
}
