﻿using FundedMillionaires.Web.Mvc.Models;

namespace FundedMillionaires.Web.Mvc.Services
{
    public class FaqService
    {
        public FaqViewModel GetAllFaqs()
        {
            List<Faq> list = new List<Faq>();
            FaqViewModel model = new FaqViewModel();
            model.Account = GetAccountFaqs();
            model.General = GetGeneralFaqs();
            model.AboutUs = GetAboutUsFaqs();
            model.Withdrawals = GetWithdrawalsFaqs();
            return model;
        }

        public List<Faq> GetAccountFaqs()
        {
            string CategoryId = "accordion-account";
            string CategoryName = "Account";

            List<Faq> list = new List<Faq>();

            list.Add(new Faq
            {
                Id = 1,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "How long it takes to get Funded Account?",
                Description = "It takes us around 24 to 72 hours to complete the document verification and get the Funded account ready for the Trader.  We give trader choices of what kind of spreads they want to work with and commission so we customise the trading account accordingly."
            });

            list.Add(new Faq
            {
                Id = 2,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "How much is the Profit Split in FundedMillionaires?",
                Description = "In the first withdrawal you'll get 60% of the profit; after that, 75%, and 90% of the profit share will be applied consecutively."
            });

            list.Add(new Faq
            {
                Id = 3,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "News trading is allowed?",
                Description = "Yes."
            });

            list.Add(new Faq
            {
                Id = 4,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "Is EA allowed?",
                Description = "Yes we do allow EAs."
            });

            list.Add(new Faq
            {
                Id = 5,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "When are we eligible for the salary?",
                Description = "After the 5th withdrawal trader becomes eligible for the Salary. <br />This is how salary is calculated:- We give 1 %  of the trading capital a trader is trading with us as salary per month. <br />For ex:- Account size is $500k , so the salary will be 1% of 5,00,000 i.e $5000."
            });

            list.Add(new Faq
            {
                Id = 6,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "Is there any time limit to complete the assessment?",
                Description = "No."
            });

            list.Add(new Faq
            {
                Id = 7,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "Is there any inactivity rule?",
                Description = "If the trader doesn't trade for 30 day , the account will be terminated for inactivity. However , if the trader intimates about the inactivity so there will be no termination."
            });

            list.Add(new Faq
            {
                Id = 8,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "Why do we have various account ranges?",
                Description = "These ranges have been added for our Assessment and Rapid funding programs. Investors will assess and fund traders based on their performance in the assessments. Investors can choose to fund from the following ranges:-<br />100k-500k<br />500k-1Mil<br />1Mil-10Mil<br />10Mil-50Mil<br />"
            });


            return list;
        }

        public List<Faq> GetGeneralFaqs()
        {
            string CategoryId = "accordion-general";
            string CategoryName = "General";

            List<Faq> list = new List<Faq>();

            list.Add(new Faq
            {
                Id = 9,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "Trade copying is allowed?",
                Description = "Copying trades from your personal account is allowed. You cannot not copy trades from someone else's account."
            });

            list.Add(new Faq
            {
                Id = 10,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "What are the Restricted/Prohibited Trading Strategies at FundedMillionaires?",
                Description = "<p>FundedMillionaires strictly prohibits any form of cheating or exploitation of the platform, as it goes against our Terms of Service (TOS) agreed upon during registration. Traders are urged to thoroughly read our Terms of Service and understand the following guidelines to prevent unintended consequences.</p><p>Abuse of the System means that trading styles that do not reflect real market trading are not allowed and will result in a breach of our Terms of Service without any warning. Strategies that produce risk-free, consistent profits exclusively on Assessment accounts are strictly forbidden. Traders are expected to trade on their accounts as if they were Fundedmillionaires accounts. Utilizing strategies that exploit Assessment  accounts will lead to the termination of a Fundedmillionaires Trader's account, whether in the assessment phase or while a  direct funding Fundedmillionaires account, \"Pass Your Assessment ,\" \"Copy Trading Services,\" or \"Signal Services\" is also strictly prohibited, resulting in the denial of any Fundedmillionaires accounts and a permanent ban from all Fundedmillionaires services.</p><p>Example Strategies That Violate our Terms of Service:<br />High-Frequency Trading:<br />High-Frequency Trading (HFT) is a trading strategy characterized by the use of sophisticated computer algorithms and high-speed telecommunication networks to execute an excessive number of trades within milliseconds. This strategy aims to capitalize on minuscule price fluctuations and exploit market inefficiencies. While HFT may seem enticing due to its potential for rapid profit generation, it poses significant risks and can have detrimental effects on the market.</p><p>Here's why HFT is restricted on the FundedMillionaires  platform:<br />HFT trading can distort market prices and create artificial demand or supply. By executing a large volume of trades within milliseconds, HFT traders can create false impressions of market activity, influencing other participants' decisions and leading to market manipulation. Excessive trading volumes generated by high-frequency trading can disrupt market stability. The rapid influx and outflow of orders can create volatility, leading to erratic price fluctuations and increased market uncertainty, making it challenging for other traders to make informed decisions. Due to huge amounts of trades in a short period of time, the servers usually freeze and create consequences.</p><p>Example: An HFT trader places a series of buy orders within milliseconds, causing the price of a market to rise artificially. Other traders, observing the sudden surge, may be misled into buying at inflated prices, leading to potential losses when the market corrects itself. An HFT trader also executes a large number of rapid-fire trades within milliseconds, causing rapid price swings in a particular asset. The increased volatility and unpredictability make it difficult for other market participants to accurately assess market conditions and plan their trading strategies.<br />Latency Trading:<br />Latency trading refers to the practice of executing trades based on delayed market data or exploiting delays in the execution of trades to secure guaranteed profits. At FundedMillionaires , latency trading is strictly prohibited due to its unethical nature and violation of fair trading practices in the financial markets.<br />Example: Latency trading goes against the principles of fair and transparent trading. It undermines the integrity of the financial markets by introducing an element of unfairness and eroding trust among market participants. A latency trader identifies a delay in trade execution and takes advantage of the price discrepancy between the delayed trade execution and the current market price. They execute a large volume of trades within seconds to capitalize on the price difference, creating artificial buying or selling pressure and manipulating the market. By knowingly engaging in such practices, they compromise the fairness and transparency that underpin a healthy trading ecosystem.<br />Copy Trading From Others:<br />Fundedmillionaires  allows traders to engage in copy trading from another Fundedmillionaires  account, prop firm, or retail broker, provided that the accounts are owned by the same individual. This means that you can copy trades from any account(s) that you own.</p><p>However, copy trading between multiple accounts not owned by the same individual, including those of relatives, family members, or friends, is strictly prohibited.</p><p>To get more details regarding copy-trading<br />Hedging or Group Hedging Across Various Accounts:<br />Hedging is allowed at Fundedmillionaires under the same account.<br />However, hedging using multiple accounts is not allowed as it does not reflect a proper trading strategy. For example, if you have two accounts, you are not allowed to place hedged entries between them.</p><p>Example: Let's say you have two trading accounts with us, Account A and Account B. You buy 1 lot of EUR/USD on Account A and simultaneously sell 1 lot of EUR/USD on Account B to hedge the position. This is not allowed.<br />Let's say you have two trading accounts with us, Account A and Account B. You buy 1 lot of EUR/USD on Account A and simultaneously sell 1 lot of EUR/USD on Account A to hedge the position. This is allowed.</p><p>Hedging or group hedging across multiple accounts refers to a trading tactic where a person or group opens multiple accounts and executes opposing trades on the same asset across all accounts. This strategy aims to capitalize on price fluctuations while minimizing market risk. However, it does not reflect genuine trading intelligence and is prohibited.<br />Any form of Arbitrage Trading:<br />Arbitrage trading refers to the practice of exploiting price discrepancies or time lags across different markets or platforms to generate risk-free profits. At FundedMillionaires, any form of arbitrage trading is strictly prohibited due to its unethical nature and potential to disrupt fair market conditions.</p><p>Example: Arbitrage trading can distort market prices and hinder the efficient allocation of resources. By capitalizing on price discrepancies, arbitrage traders can cause prices to deviate from their true fundamental values, creating inconsistencies in market pricing. A trader engages in statistical arbitrage by simultaneously buying and selling related instruments based on historical price patterns. Their trading activity distorts the market pricing of these instruments, creating misalignments between the perceived value and their actual worth. Also, Large-scale arbitrage activities can trigger rapid price movements, creating artificial market fluctuations and destabilizing the normal price discovery process.<br />Tick Scalping:<br />Tick scalping refers to a trading strategy where traders aim to profit from small price fluctuations by executing a high volume of trades within a short time frame. At FundedMillionaires, limitations have been imposed on tick scalping as a result of its capacity for market manipulation and disruptive trading practices.<br />Consequences of Exceeding the Limit:<br />The Fundedmillionaires  team will issue the first warning to adjust trading strategies when an account exceeds 2,000 messages for the initial occurrence. Subsequently, a second warning will be sent should the account exceed this message limit once more. If an account reaches this limit for the third time, it will be considered hyperactive, and the account will be breached. Furthermore, If an account generates 15,000 messages in a day, the account will be forcefully disabled to prevent further strain on the system.</p><p>Use of Platform or Data Freezing Due to Demo Server Errors:<br />The use of any unfair advantage, such as platform or data freezing due to demo server errors, is strictly prohibited. This ensures a level playing field for all traders and prevents misleading or deceiving practices. Traders found engaging in such behavior will be investigated, and appropriate actions, including the revocation of access to our demo servers, may be taken. In the event of server issues, traders are encouraged to report the problem to FundedMillionaires's support team promptly.</p><p>Use of guarantee of profit with limit orders during low liquid market</p><p>The implementation of guaranteed adherence to limit orders is forbidden as it has the potential to bypass regulatory constraints and exploit the low-liquid market.<br />This exploitative behavior stems from the fact that trading occurs on a simulated platform. Utilizing such guaranteed compliance with limit orders, traders might evade the order executions that would have taken place in an actual market scenario, rendering this approach inconsistent with genuine financial market operations. As a result, this type of trading activity violates the Terms of Service established by Fundedmillionaires.</p>"
            });

            list.Add(new Faq
            {
                Id = 11,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "Will I get any Certificate?",
                Description = "<p>Fundedmillionaires deeply appreciates your trading skills and talents. As a token of recognition for your achievements, you will be awarded certificates from FundedNext. There are 2 types of certificates available:<br />1. Certicate of achivement<br />2. Certificate of withdraw<br /></p>"
            });

            list.Add(new Faq
            {
                Id = 12,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "Who will pay Tax on my profit?",
                Description = "Traders are solely responsible for handling tax obligations in accordance with the laws and regulations of their respective countries.\r\nThe focus at Fundedmillionaires is to provide traders with the opportunity to earn and maximize their profits while following the legal and regulatory frameworks governing taxation."
            });

            list.Add(new Faq
            {
                Id = 13,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "Is there any Age Restriction to joining Fundedmillionaires?",
                Description = "<p>To open a Fundedmillionaires trading account with Fundedmillionaires, you must be at least 18 years old. This is because trading involves significant risks and requires a certain level of maturity and responsibility.<br />Furthermore, opening a Fundedmillionaires trading account involves entering into contractual agreements. Legally, individuals under the age of 18 may not possess the capacity to enter into binding contracts, including trading agreements.</p>"
            });

            list.Add(new Faq
            {
                Id = 14,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "Why are we charging registration fees if we are not working on subscription models like other prop firms?",
                Description = "Yes that's correct we don't work on subscription model like B book prop firms . We mainly charge registration fee for our expenses which we incur to run this firm which is the reason why we charge way less. Also, the main reason about charging registration fee is the basic human nature . We are traders and humans above all , we all know how a free service or stuff is treated. Nothing is respected until it have a cost attached to it .\r\n\r\n"
            });

            list.Add(new Faq
            {
                Id = 15,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "Is there a consistency rule?",
                Description = "<p><b>ONLY FOR RAPID FUNDING</b><br />Minimum Trading Days: Traders need to participate in at least 5 trading days for each withdrawal.<br />Withdrawal Review: When you request a withdrawal, we'll review your trading history and adjust your balance for any trades outside your trading range.<br />Calculating Average Lot Size: Find your average lot size by dividing the total lot volume by the number of executed trades.<br />Example:<br /><br />​Total lots traded: 100<br />Total trades executed: 50<br />Average lot size = 100 lots / 50 trades = 2 lots<br />Determining Trading Range: Your average lot size range is calculated as follows:<br /><br />​Bottom of your range = Average Lot Size x 0.25<br />Top of your range = Average Lot Size x 2.00<br />In our example:<br /><br />​Bottom of the range: 2 lots x 0.25 = 0.5 lots<br />Top of the range: 2 lots x 2.0 = 4 lots<br />So, your trades must be between 0.5 and 4 lots.<br />Range Enforcement: Any trades outside this range will be removed during the withdrawal process. Additionally, no single trade can contribute more than 25% of your profit.<br />This rule helps ensure consistency in your trading and aligns with our current policy.</p>"
            });
            return list;
        }
        public List<Faq> GetAboutUsFaqs()
        {
            string CategoryId = "accordion-aboutus";
            string CategoryName = "AboutUs";

            List<Faq> list = new List<Faq>();

            list.Add(new Faq
            {
                Id = 16,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "Who we are?",
                Description = "FundedMillionaires is the First Firm in the trading and investment space which connects Skilled traders with Investors. 100% of our funded traders are seamlessly integrated onto our \"A\" book, where they indirectly manage real capital. This dynamic entails the replication of trades in the actual markets, empowering traders to effectively oversee live liquidity. We as a Firm don't depend on the Failed Subscription fees of traders to be profitable ,but on the traders ability to generate profit trading the Financial Markets, which eliminates our ability of failing to give payouts like the Traditional Prop firms The Success of FundedMillionaires depends on our traders trading the financial markets and not on the traders blowing their accounts to thrive as a firm."
            });
            list.Add(new Faq
            {
                Id = 17,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "How are we different?",
                Description = "Prop Firms mainly work on the model of Subscription Fee. They mostly don't have any Funding to give to a trader to trade , which is why big payouts are denied . We at FundedMillionaires works as Bridge between Investors and Traders and make sure that traders get the right funding according to their potential and investors get appropriate profits on their investment. We have 50+ investors totally over Billion Dollars. For traders working with FundedMillionaires will work as not only a Trading investment but also as a big opportunity for traders to network with such big players."
            });
            return list;
        }

        public List<Faq> GetWithdrawalsFaqs()
        {
            string CategoryId = "accordion-withdrawals";
            string CategoryName = "Withdrawals";

            List<Faq> list = new List<Faq>();

            list.Add(new Faq
            {
                Id = 18,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "What is our payout structure?",
                Description = "We Impose no limit on traders for requesting their Payouts. Traders can request withdrawals anytime they want and as many times they want. Traders simply have to contact the Designated account manager and the amount is processed within 24 hours. We have no Payout rules and we never deny any withdrawals based on hidden Terms and Conditions."
            });
            list.Add(new Faq
            {
                Id = 19,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "How long does it typically take to process a withdrawal request?",
                Description = "<p>Withdrawals are typically processed within <b>24–36 working hours</b>.</p>"
            });
            list.Add(new Faq
            {
                Id = 20,
                CategoryId = CategoryId,
                CategoryName = CategoryName,
                Title = "What are the available withdrawal methods?",
                Description = "FundedMillionaires offers a range of convenient withdrawal methods to ensure you have flexibility when accessing your profits. The available methods include Perfect Money, USDT (ERC20, TRC20), USDC (ERC20, TRC20), Bank Transfer and Wise."
            });
            return list;
        }

    }
}
