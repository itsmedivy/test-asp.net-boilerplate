﻿using FundedMillionaires.Web.Mvc.Models;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;
using System.Net;
using System.Net.Mail;

namespace FundedMillionaires.Web.Mvc.Services
{
    public class EmailService
    {
        private readonly ILogger<EmailService> _logger;
        private readonly AppSettingModel _setting;

        private readonly EmailSetting emailSetting;

        public EmailService(ILogger<EmailService> logger, IOptions<AppSettingModel> options)
        {
            _logger = logger;
            _setting = options.Value;
            emailSetting = _setting.EmailSettings;
        }

        public bool SendEmail(string to, string cc, string subject, string body)
        {
            bool isSent = false;
            Log.Information("------ Process: SendEmail Starts --------");
            try
            {
                var mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(emailSetting.Username, emailSetting.DisplayName);

                to = removeDuplicateEmails(to);
                var spl_To = to.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (var spl in spl_To)
                    mailMessage.To.Add(spl.Replace(";",""));

                cc = removeDuplicateEmails(cc);
                var spl_CC = to.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (var spl in spl_CC)
                    mailMessage.To.Add(spl.Replace(";", ""));

                mailMessage.Subject = subject;
                mailMessage.Body = body;
                mailMessage.IsBodyHtml = true; // Set to true if the body is HTML

                var smtpClient = new SmtpClient(emailSetting.SmtpServer, emailSetting.SmtpPort)
                {
                    Credentials = new NetworkCredential(emailSetting.Username, emailSetting.Password),
                    EnableSsl = emailSetting.EnableSsl
                };

                Log.Information("------ Process: SendEmail Payload --------");
                string json = JsonConvert.SerializeObject(new { To = to, Subject = subject, Body = body }, formatting: Formatting.Indented);
                Log.Information(json);
                smtpClient.Send(mailMessage);
                isSent = true;
                Log.Information("------ Process: SendEmail Success: Email Sent --------");
            }
            catch (Exception ex)
            {
                Log.Error($"------ Process: SendEmail Error: {ex.Message}");
            }
            Log.Information("------ Process: SendEmail Ends --------");
            return isSent;
        }

        public bool SendTestMail()
        {
            bool isSent = false;
            string to = emailSetting.TestEmail;
            string subject = "This is a Test Email";
            string body = "<p>Please ignore this <b>Test Email</b>.</p>";
            isSent = SendEmail(to, "", subject, body);
            return isSent;
        }

        private string removeDuplicateEmails(string emails)
        {
            if (string.IsNullOrWhiteSpace(emails))
            {
                return string.Empty;
            }

            // Split the emails by semicolon
            string[] emailArray = emails.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries);

            // Use a HashSet to remove duplicates
            HashSet<string> uniqueEmails = new HashSet<string>(emailArray, StringComparer.OrdinalIgnoreCase);

            // Join the unique emails back into a semicolon-separated string
            string result = string.Join(";", uniqueEmails);

            return result;
        }
    }
}
