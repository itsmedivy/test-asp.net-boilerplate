﻿using FundedMillionaires.Web.Mvc.Models;
using Microsoft.Extensions.Options;

namespace FundedMillionaires.Web.Mvc.Services
{
    public class FileService
    {
        private readonly AppSettingModel _settings;
        private readonly IWebHostEnvironment _env;
        public FileService(IOptions<AppSettingModel> options, IWebHostEnvironment env)
        {
            _settings = options.Value;
            _env = env;
        }

        public async Task<(bool, string)> UploadFile(IFormFile file, long? sizeLimit = null, string allowedExtensions = null)
        {
            string path = "";
            try
            {
                if (file != null && file.Length > 0)
                {
                    //Validate the file
                    (bool isValid, string errmsg) = FileValidation(file, sizeLimit, allowedExtensions);
                    if (!isValid)
                        return (false, errmsg);

                    string fileExt = Path.GetExtension(file.FileName);
                    string newFileName = $"{string.Format("{0:yyyyMMddhhmm}", DateTime.Now)}{Path.GetRandomFileName()}{fileExt}";

                    path = Path.GetFullPath(Path.Combine(_env.WebRootPath, _settings.FileUploadSettings.UploadPath));
                    if (!Directory.Exists(path))
                        Directory.CreateDirectory(path);

                    using (var fileStream = new FileStream(Path.Combine(path, newFileName), FileMode.Create))
                    {
                        await file.CopyToAsync(fileStream);
                    }
                    return (true, newFileName);
                }
                else
                {
                    return (false, "File has null value or is empty.");
                }
            }
            catch (Exception ex)
            {
                throw new Exception("File upload failed", ex);
            }
        }

        public (bool, string) FileValidation(IFormFile file, long? sizeLimit = null, string allowedExtensions = null)
        {
            bool _isValid = true;
            string _message = "";

            long fileSizeLimit = sizeLimit ?? _settings.FileUploadSettings.SizeLimit;

            string[] allowedExts = !string.IsNullOrEmpty(allowedExtensions) ? allowedExtensions.Split(",", StringSplitOptions.RemoveEmptyEntries)
                                    : _settings.FileUploadSettings.AllowedExtensions.Split(",", StringSplitOptions.RemoveEmptyEntries);

            string fileExt = Path.GetExtension(file.FileName).ToLower();

            if (file.Length > fileSizeLimit)
            {
                _isValid = false;
                _message += "File size exceeds 2MB limit";
            }

            if (string.IsNullOrEmpty(fileExt) || !allowedExts.Contains(fileExt))
            {
                if (_isValid)
                    _isValid = false;
                _message += $"{(string.IsNullOrEmpty(_message) ? "" : ", ")}Invalid File Extension, Allowed file types are ({_settings.FileUploadSettings.AllowedExtensions})";
            }

            return (_isValid, _message);
        }
    }
}
