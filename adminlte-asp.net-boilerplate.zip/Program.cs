using FundedMillionaires.Web.Mvc.DataAccess.Contexts;
using FundedMillionaires.Web.Mvc.Helpers;
using FundedMillionaires.Web.Mvc.Models;
using FundedMillionaires.Web.Mvc.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Serilog;
using FileService = FundedMillionaires.Web.Mvc.Services.FileService;

var builder = WebApplication.CreateBuilder(args);

//  Configure Logger
Log.Logger = new LoggerConfiguration().WriteTo.File(
        System.IO.Path.Combine(System.Environment.CurrentDirectory, "LogFiles", $"log.txt"),
        rollingInterval: RollingInterval.Day,
        fileSizeLimitBytes: 10 * 1024 * 1024,
        retainedFileCountLimit: 2,
        rollOnFileSizeLimit: true,
        shared: true, flushToDiskInterval: TimeSpan.FromSeconds(1))
    .CreateLogger();
Log.Information("MVC Started at {0:hh:mm:ss}", DateTime.Now);

// Configure AppSettings
builder.Configuration.AddJsonFile("appsettings.json", optional: true, reloadOnChange: true).AddEnvironmentVariables();
builder.Services.Configure<AppSettingModel>(builder.Configuration.GetSection("AppSettings"));
Log.Information("AppSettings loaded into memory at {0:hh:mm:ss}", DateTime.Now);

string connectionString = builder.Configuration.GetConnectionString("default");
builder.Services.AddDbContext<AppDbContext>(c => c.UseSqlServer(connectionString));

builder.Services.AddIdentity<IdentityUser, IdentityRole>().AddEntityFrameworkStores<AppDbContext>().AddDefaultTokenProviders();
//builder.Services.Configure<PasswordHasherOptions>(options => options.CompatibilityMode = PasswordHasherCompatibilityMode.IdentityV2);

// Add services to the container.
builder.Services.AddHttpContextAccessor();
builder.Services.AddControllersWithViews().AddRazorRuntimeCompilation();

builder.Services.AddSingleton<AppSettingModel>();
builder.Services.AddSingleton<FaqService>();
builder.Services.AddSingleton<PaymentService>();
builder.Services.AddScoped<EmailService>();
builder.Services.AddScoped<FileService>();

builder.Services.AddSingleton<AppTitleHelper>();
builder.Services.AddSingleton<AuthUserHelper>();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "areas",
    pattern: "{area:exists}/{controller=Home}/{action=Index}/{id?}");

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
