﻿using FundedMillionaires.Web.Mvc.Areas.CmsPanel.Models;
using FundedMillionaires.Web.Mvc.Models;
using FundedMillionaires.Web.Mvc.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Serilog;

namespace FundedMillionaires.Web.Mvc.Controllers
{
    public class ServicesController : Controller
    {
        private readonly ILogger<ServicesController> _logger;
        private readonly AppSettingModel _setting;
        private readonly EmailService _emailService;
        private readonly FileService _file;
        public ServicesController(ILogger<ServicesController> logger, IOptions<AppSettingModel> options, EmailService emailService, FileService file)
        {
            _logger = logger;
            _setting = options.Value;
            _emailService = emailService;
            _file = file;
        }

        public IActionResult Index()
        {
            return View();
        }

        [Route("services/direct-funding")]
        public IActionResult DirectFunding()
        {
            return View();
        }

        [Route("services/rapid-funding")]
        public IActionResult RapidFunding()
        {
            return View();
        }

        [Route("services/assessment-funding")]
        public IActionResult AssessmentFunding()
        {
            return View();
        }

        [Route("services/register")]
        public IActionResult Register()
        {
            string qService = "", qOp = "";
            string servName = "", servInv = "";
            decimal servAmt = 0;
            string servPriceId = "price_1PGJnY016cnQWqmwNeGVnEMi";


            if (!string.IsNullOrEmpty(HttpContext.Request.Query["s"]))
                qService = HttpContext.Request.Query["s"];

            if (!string.IsNullOrEmpty(HttpContext.Request.Query["op"]))
                qOp = HttpContext.Request.Query["op"];

            if (qService == "rr")
            {
                servName = "Rapid Funding";
                if (qOp == "1")
                {
                    servInv = "200k-500k";
                    //servAmt = 499;
                    servAmt = 99;
                    //servPriceId = "price_1PGh49016cnQWqmwiUL8QuAW";
                    servPriceId = "price_1PNEjf016cnQWqmwyNhaFcnZ";
                }
                else if (qOp == "2")
                {
                    servInv = "500k-1Mil";
                    //servAmt = 999;
                    servAmt = 99;
                    //servPriceId = "price_1PGh5B016cnQWqmwxPZnMqiO";
                    servPriceId = "price_1PNEmk016cnQWqmwe7m70qku";
                }
                else if (qOp == "3")
                {
                    servInv = "1Mil-10Mil";
                    //servAmt = 1499;
                    servAmt = 99;
                    //servPriceId = "price_1PGh5z016cnQWqmw9W4Zy5Im";
                    servPriceId = "price_1PNEoA016cnQWqmwQPEK6g6o";
                }
                else if (qOp == "4")
                {
                    servInv = "10Mil-50Mil";
                    //servAmt = 1999;
                    servAmt = 99;
                    //servPriceId = "price_1PGh6x016cnQWqmwB0v3Rccx";
                    servPriceId = "price_1PNEpr016cnQWqmwvfMjSsYo";
                }
            }
            else if (qService == "ar")
            {
                servName = "Assessment Funding";
                if (qOp == "1")
                {
                    servInv = "100k-500k";
                    servAmt = 259;
                    servPriceId = "price_1PGfYm016cnQWqmwR8mMyMv6";
                }
                else if (qOp == "2")
                {
                    servInv = "500k-1Mil";
                    servAmt = 529;
                    servPriceId = "price_1PGfZF016cnQWqmwmUfssLyV";
                }
                else if (qOp == "3")
                {
                    servInv = "1Mil-10Mil";
                    servAmt = 789;
                    servPriceId = "price_1PGfZi016cnQWqmwj2fsSe2O";
                }
                else if (qOp == "4")
                {
                    servInv = "10Mil-50Mil";
                    servAmt = 1049;
                    servPriceId = "price_1PGh1c016cnQWqmwpPcBYskw";
                }
            }
            else if (qService == "dr")
            {
                servName = "Direct Funding";
                if (qOp == "1")
                {
                    servInv = "500k-50Mil";
                    servAmt = 1999;
                    servPriceId = "price_1PGhOf016cnQWqmwy8uokOQ0";
                }
            }

            RegisterViewModel mm = new RegisterViewModel
            {
                FirstName = "",
                LastName = "",
                Phone = "",
                Email = "",
                ProfitsPerYear = 1,
                TradeInstruments = "",
                TradingStyle = "",
                Comments = ""
            };

            ViewData["ServiceName"] = servName;
            ViewData["ServiceInv"] = servInv;
            ViewData["ServiceAmt"] = servAmt;
            ViewData["ServicePriceId"] = servPriceId;
            return View(mm);
        }


        [HttpPost]
        [Route("services/register")]
        public IActionResult Register(IFormFile FileTrackRecord, [FromForm] RegisterViewModel model)
        {
            Log.Information("==== REQUEST: Register START ====");
            Log.Information("======== RegisterViewModel model");

            if (model != null)
            {
                model.ClientId = Guid.NewGuid().ToString();

                //Upload TrackRecord and Send registeration details over mail to admin.
                SaveCustomerDetails(model, FileTrackRecord);

                Log.Information(JsonConvert.SerializeObject(model, Formatting.Indented));
                PayModel payModel = new PayModel
                {
                    ClientRefId = model.ClientId,
                    Email = model.Email,
                    ProductPriceId = model.PriceId
                };
                return RedirectToAction("PayWithStripe", "Payment", payModel);
            }
            Log.Information("==== REQUEST: Register END ====");
            return View(model);
        }


        private void SaveCustomerDetails(RegisterViewModel model, IFormFile FileTrackRecord)
        {
            string fileUploadResponse = "";
            bool isFileUploadSuccess = false;

            long allowedFileSize = 5242880; // 5MB
            string allowedExt = ".jpg,.png,.pdf";
            try
            {
                if (FileTrackRecord != null)
                    (isFileUploadSuccess, fileUploadResponse) = _file.UploadFile(FileTrackRecord, allowedFileSize, allowedExt).Result;

                if (!isFileUploadSuccess)
                    Log.Information("======== FileTrackRecord Upload failed : " + fileUploadResponse);

                string _html2 = "";
                _html2 += $"<p>Dear Admin,</p>";
                _html2 += $"<p>A customer has initiated Product Purchase. Do find the Registration details below:</p>";
                _html2 += $"<ul>";
                _html2 += $"	<li><strong>Name:</strong> {model.FirstName} {model.LastName}</li>";
                _html2 += $"	<li><strong>Phone:</strong> {model.Phone}</li>";
                _html2 += $"	<li><strong>Email:</strong> {model.Email}</li>";
                _html2 += $"	<li><strong>Profits Per Year:</strong> {model.ProfitsPerYear}</li>";
                _html2 += $"	<li><strong>Trade Instruments:</strong> {model.TradeInstruments}</li>";
                _html2 += $"	<li><strong>Trading Style:</strong> {model.TradingStyle}</li>";
                _html2 += $"	<li><strong>Account Currency:</strong> {model.AccountCurrency}</li>";
                _html2 += $"	<li><strong>Trading Platform:</strong> {model.TradingPlatform}</li>";
                _html2 += $"	<li><strong>Comments:</strong> {model.Comments}</li>";
                _html2 += $"	<li><strong>Client Id (for admin use only):</strong> {model.ClientId}</li>";
                _html2 += $"</ul>";

                if (isFileUploadSuccess)
                    _html2 += $"<p><strong>You can download the Track Record</strong>: <a href='https://fundedmillionaires.com/SharedDocuments/{fileUploadResponse}'>[Click here to download]</a></p>";

                _html2 += $"<p>Please respond to the user as soon as possible.</p>";
                _html2 += $"<p>Best regards,</p>";
                _html2 += $"<p>Funded Millionaires</p>";

                bool isEmailSent = _emailService.SendEmail("support@fundedmillionaires.com", "info@fundedmillionaires.com", $"Product Purchase initiated from {model.FirstName} {model.LastName}", _html2);
                if (isEmailSent)
                    Log.Information("Customer Registration details Email sent to support@fundedmillionaires.com.");
                else
                    Log.Error("Customer Registration details Email failed to sent.");
            }
            catch (Exception)
            {
                Log.Error("Unable to upload Track File Record.");
            }
        }
    }
}
