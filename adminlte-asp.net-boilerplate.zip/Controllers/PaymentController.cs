﻿using FundedMillionaires.Web.Mvc.Models;
using FundedMillionaires.Web.Mvc.Services;
using Microsoft.AspNetCore.Mvc;
using Serilog;

namespace FundedMillionaires.Web.Mvc.Controllers
{
    public class PaymentController : Controller
    {
        private readonly PaymentService _payService;
        private readonly AppSettingModel _setting;
        private readonly EmailService _emailService;
        public PaymentController(PaymentService payService, AppSettingModel setting, EmailService emailService)
        {
            _payService = payService;
            _setting = setting;
            _emailService = emailService;
        }

        public IActionResult Index()
        {
            return View();
        }

        [Route("payment/stripe")]
        public IActionResult PayWithStripe(PayModel payModel)
        {
            PayResponseModel resp = _payService.Pay(payModel);
            TempData["StrpSessionId"] = resp.SessionId;
            return Redirect(resp.StripeUrl);
        }

        [Route("payment/complete")]
        public IActionResult PayComplete()
        {
            string sId = "";
            PaymentResponseViewModel respModel = new PaymentResponseViewModel();
            string _title = "Payment Failed";
            string _message = "Due to some unexpected reason your payment has failed. Don`t worry your money is safe, our accounts team is checking what went wrong. You will recieve a mail shortly.";

            if (TempData["StrpSessionId"] != null)
            {
                sId = TempData["StrpSessionId"].ToString();
                var session = _payService.GetSession(sId);
                if (session != null)
                {
                    respModel.ClientRefId = session.ClientRefId;
                    respModel.CustomerEmail = session.CustomerEmail;
                    respModel.Amount = session.Amount;
                    respModel.CurrencyCode = session.CurrencyCode;

                    if (session.Status == "open")
                    {
                        if (session.PaymentStatus == "paid")
                        {
                            _title = "Payment Complete";
                            _message = "Your payment has been successfully completed.";
                        }
                        else if (session.PaymentStatus == "un_paid")
                        {
                            _title = "Payment Pending";
                            _message = "Your payment is pending.";
                        }
                        else if (session.PaymentStatus == "no_payment_required")
                        {
                            _title = "No Payment Required";
                            _message = "No payment is required for this transaction.";
                        }
                        else
                        {
                            _title = "Payment Status Unknown";
                            _message = "The payment status is unknown.";
                        }
                    }
                    else if (session.Status == "complete" || session.Status == "expired")
                    {
                        if (session.Status == "complete")
                        {
                            _title = "Payment Complete";
                        }
                        else
                        {
                            _title = "Payment Expired";
                        }

                        _message = _title == "Payment Complete" ? "Your payment has been successfully completed." : "Your payment session has expired.";
                    }
                    else
                    {
                        _title = "Payment Status Unknown";
                        _message = "The payment status is unknown. We are checking your payment in our system and will notify you soon.";
                    }
                }
            }
            respModel.Status = _title == "Payment Complete";
            respModel.Title = _title;
            respModel.StatusMessage = _message;
            SendEmail(respModel);

            return View(respModel);
        }

        [Route("payment/cancel")]
        public IActionResult PayCancel()
        {
            return View();
        }


        public void SendEmail(PaymentResponseViewModel model)
        {
            string _html2 = "";
            _html2 += $"<p>Dear Admin,</p>";
            _html2 += $"<p>Customer Payment Transaction Details:</p>";
            _html2 += $"<ul>";
            _html2 += $"	<li><strong>Status:</strong> {(model.Status ? "SUCCESS" : "FAILED")}</li>";
            _html2 += $"	<li><strong>Email:</strong> {model.CustomerEmail}</li>";
            if (model.Status && model.Amount.HasValue)
                _html2 += $"	<li><strong>Amount:</strong> {model.CurrencyCode} {model.Amount.Value}</li>";
            _html2 += $"	<li><strong>Client Ref Id (for admin use only):</strong> {model.ClientRefId}</li>";
            _html2 += $"</ul>";

            _html2 += $"<p>Please respond to the user as soon as possible.</p>";
            _html2 += $"<p>Best regards,</p>";
            _html2 += $"<p>Funded Millionaires</p>";

            bool isEmailSent = _emailService.SendEmail("support@fundedmillionaires.com", "info@fundedmillionaires.com", $"Customer Payment Transaction {(model.Status ? "SUCCESS" : "FAILED")}", _html2);
            if (isEmailSent)
                Log.Information("Customer payment details Email sent to support@fundedmillionaires.com.");
            else
                Log.Error("Customer payment details Email failed to sent.");

            isEmailSent = _emailService.SendEmail("support@fundedmillionaires.com", "divy.codm@gmail.com", $"Customer Payment Transaction {(model.Status ? "SUCCESS" : "FAILED")}", _html2);
            if (isEmailSent)
                Log.Information("Customer payment details Email sent to divy.codm@gmail.com.");
            else
                Log.Error("Customer payment details Email failed to sent.");
        }

        //[Route("payment/live-test")]
        //public IActionResult LiveTest()
        //{
        //    PayModel payModel = new PayModel
        //    {
        //        ClientRefId = Guid.NewGuid().ToString(),
        //        Email = "Ak452632@gmail.com",
        //        ProductPriceId = "price_1PGmjm016cnQWqmwqjkcdEru"
        //    };
        //    return RedirectToAction("PayWithStripe", "Payment", payModel);
        //    //if(_setting.EnableTestPay)
        //    //{

        //    //}
        //    //else
        //    //{
        //    //    TempData["TestPayMessage"] = "Test Payment not allowed";
        //    //    return RedirectToAction("Index", "Home");
        //    //}
        //}
    }
}
