using FundedMillionaires.Web.Mvc.DataAccess.Contexts;
using FundedMillionaires.Web.Mvc.DataAccess.Models;
using FundedMillionaires.Web.Mvc.Models;
using FundedMillionaires.Web.Mvc.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System.Diagnostics;

namespace FundedMillionaires.Web.Mvc.Controllers
{

    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly FaqService _faqService;
        private readonly AppSettingModel _settings;
        private readonly EmailService _emailService;
        private readonly AppDbContext _db;
        public HomeController(ILogger<HomeController> logger, AppDbContext db, FaqService faqService, IOptions<AppSettingModel> options, EmailService emailService)
        {
            _logger = logger;
            _db = db;
            _faqService = faqService;
            _settings = options.Value;
            _emailService = emailService;
        }

        public IActionResult Index()
        {
            ViewData["ShowOffer"] = "Y";
            return View();
        }

        [Route("about")]
        public IActionResult About()
        {
            return View();
        }

        [Route("contact")]
        public IActionResult Contact()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SendMessage([FromForm] ContactFormModel model)
        {
            if (model != null)
            {
                string _html1 = "";
                _html1 += $"<p> Dear {model.Name},</p>";
                _html1 += "<p>Thank you for reaching out to us. We have received your message and will get back to you as soon as possible.</p>";
                _html1 += "<p>If you have any further questions or need immediate assistance, please don't hesitate to contact us at support@fundedmillionaires.com.</p>";
                _html1 += "<p>Best regards,</p>";
                _html1 += "<p>Funded Millionaires</p>";
                _emailService.SendEmail(model.Email, "", $"Thank You for Contacting Us!", _html1);

                string _html2 = "";
                _html2 += $"<p>Dear Admin,</p>";
                _html2 += $"<p>You have received a new message from your website's contact form. Here are the details:</p>";
                _html2 += $"<ul>";
                _html2 += $"	<li><strong>Name:</strong> {model.Name}</li>";
                _html2 += $"	<li><strong>Email:</strong> {model.Email}</li>";
                _html2 += $"	<li><strong>Message:</strong> {model.Comment}</li>";
                _html2 += $"</ul>";
                _html2 += $"<p>Please respond to the user as soon as possible.</p>";
                _html2 += $"<p>Best regards,</p>";
                _html2 += $"<p>Funded Millionaires</p>";
                _emailService.SendEmail("support@fundedmillionaires.com", "info@fundedmillionaires.com", $"New Contact Form Submission from {model.Name}", _html2);
                return Ok(new { alert = "alert-success", message = "Thank you for submitting the form. Our team will contact you soon." });
            }
            else
                return Ok(new { alert = "alert-danger", message = "There are some missing entiries in the form. Please fill the required fields and try again later" });
        }

        [Route("faq")]
        public IActionResult FAQ()
        {
            FaqViewModel model = _faqService.GetAllFaqs();
            return View(model);
        }

        [Route("privacy-policy")]
        public IActionResult PrivacyPolicy()
        {
            return View();
        }

        [Route("terms-conditions")]
        public IActionResult TermsConditions()
        {
            return View();
        }

        [Route("refund-policy")]
        public IActionResult RefundPolicy()
        {
            return View();
        }

        [Route("certificate")]
        public IActionResult Certificate(string linkid)
        {
            Trader trader = new Trader();
            try
            {
                if (!string.IsNullOrEmpty(linkid))
                {
                    trader = _db.Trader.Where(x => x.VerifiedLink == linkid).FirstOrDefault();
                    if (trader == null)
                        return RedirectToAction("Error", "Home");
                    else
                    {
                        string fullUrl = $"{Url.Action("Certificate", "Home", null, Request.Scheme, Request.Host.ToString())}?linkid={trader.VerifiedLink}";
                        trader.VerifiedLink  = fullUrl;
                        return View(trader);
                    }
                }
            }
            catch (Exception ex)
            {
                ViewData["ErrorAlert"] = "NotFound";
            }
            return View(trader);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        public IActionResult Test()
        {
            string json = "";
            if (_settings != null)
            {
                if (_settings.TestMode)
                {
                    json = JsonConvert.SerializeObject(_settings, Formatting.Indented);
                    var isSent = _emailService.SendTestMail();
                }
            }
            TempData["settings"] = json;
            return View();
        }
    }
}
