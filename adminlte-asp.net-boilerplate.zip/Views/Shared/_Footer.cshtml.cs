using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FundedMillionaires.Web.Mvc.Views.Shared
{
    public class _FooterModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
