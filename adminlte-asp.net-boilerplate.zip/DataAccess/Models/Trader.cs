﻿namespace FundedMillionaires.Web.Mvc.DataAccess.Models
{
    public class Trader
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool VerifiedTrader { get; set; }
        public string VerifiedLink { get; set; }
        public string CertificatePath { get; set; }
        public DateTime CreatedOn { get; set; } = DateTime.Now;
    }
}
