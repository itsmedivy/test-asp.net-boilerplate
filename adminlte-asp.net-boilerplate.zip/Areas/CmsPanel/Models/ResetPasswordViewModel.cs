﻿using System.ComponentModel.DataAnnotations;

namespace FundedMillionaires.Web.Mvc.Areas.CmsPanel.Models
{
    public class ResetPasswordViewModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }
}
