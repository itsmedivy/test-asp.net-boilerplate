﻿using Microsoft.AspNetCore.Mvc;

namespace FundedMillionaires.Web.Mvc.Areas.CmsPanel.Controllers
{
    public class CustomerController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
