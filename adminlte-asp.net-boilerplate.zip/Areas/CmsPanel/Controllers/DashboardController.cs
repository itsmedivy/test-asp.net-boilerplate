﻿using FundedMillionaires.Web.Mvc.Areas.CmsPanel.Filters;
using Microsoft.AspNetCore.Mvc;

namespace FundedMillionaires.Web.Mvc.Areas.CmsPanel.Controllers
{
    [Area("CmsPanel")]
	[AppAuthorize]
	public class DashboardController : Controller
    {
        // GET: DashboardController
        public ActionResult Index()
        {
            return View();
        }
    }
}
