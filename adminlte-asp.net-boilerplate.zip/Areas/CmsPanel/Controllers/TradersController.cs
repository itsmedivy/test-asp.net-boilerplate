﻿using FundedMillionaires.Web.Mvc.Areas.CmsPanel.Filters;
using FundedMillionaires.Web.Mvc.Areas.CmsPanel.Models;
using FundedMillionaires.Web.Mvc.DataAccess.Contexts;
using FundedMillionaires.Web.Mvc.DataAccess.Models;
using FundedMillionaires.Web.Mvc.Helpers;
using FundedMillionaires.Web.Mvc.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace FundedMillionaires.Web.Mvc.Areas.CmsPanel.Controllers
{
    [Area("CmsPanel")]
    [AppAuthorize]
    public class TradersController : Controller
    {
        private readonly AppDbContext _db;
        private readonly FileService _file;
        public TradersController(AppDbContext db, FileService file)
        {
            _db = db;
            _file = file;
        }

        public async Task<IActionResult> Index()
        {
            List<Trader> list = new List<Trader>();
            try
            {
                list = await _db.Trader.ToListAsync();
            }
            catch (Exception ex)
            {
                Log.Error("Error while loading traders", ex);
                ViewBag.ErrorAlert = Bootstrap.Alert(BS_Alert.Danger, "Application Error Occured", "Please try again later.");
            }
            return View(list);
        }

        public IActionResult Add()
        {
            Trader trader = new Trader();
            ViewBag.OprMode = "add";
            return PartialView("_AddEdit", trader);
        }

        public async Task<IActionResult> Edit(int id)
        {
            Trader trader = new Trader();
            trader = await _db.Trader.Where(x => x.Id == id).FirstOrDefaultAsync();
            ViewBag.OprMode = "edit";
            return PartialView("_AddEdit", trader);
        }

        public async Task<IActionResult> Details(int id)
        {
            Trader trader = new Trader();
            trader = await _db.Trader.Where(x => x.Id == id).FirstOrDefaultAsync();

            if(trader != null)
            {
                string fullUrl = $"{Url.Action("Certificate", "Home", null, Request.Scheme, Request.Host.ToString())}?linkid={trader.VerifiedLink}";
                trader.VerifiedLink = fullUrl;
            }

            return PartialView("_Details", trader);
        }


        [HttpPost]
        public async Task<IActionResult> Add([FromForm] IFormFile certificateFile, Trader model)
        {
            string fileUploadResponse = "";
            bool isFileUploadSuccess = false;
            try
            {
                model.CreatedOn = DateTime.Now;

                if (model.VerifiedTrader)
                {
                    if (certificateFile != null)
                        (isFileUploadSuccess, fileUploadResponse) = await _file.UploadFile(certificateFile);

                    if (!isFileUploadSuccess)
                        return StatusCode(StatusCodes.Status400BadRequest,
                            new BaseResponse(Constants.SC_BADREQ, fileUploadResponse, null));

                    model.VerifiedLink = Guid.NewGuid().ToString();
                    model.CertificatePath = fileUploadResponse;
                }

                await _db.Trader.AddAsync(model);
                await _db.SaveChangesAsync();
                return Ok(new BaseResponse(Constants.SC_SUCCESS, Constants.MSG_SUCCESS, model));
            }
            catch (Exception ex)
            {
                Log.Error("Error while adding new Trader.", ex);
                return StatusCode(StatusCodes.Status500InternalServerError,
                    new BaseResponse(Constants.SC_ISE, Constants.MSG_ISE, null));
            }
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, Trader model)
        {
            try
            {
                if (id == model.Id)
                {
                    Trader orgTrader = await _db.Trader.Where(x => x.Id == id).FirstOrDefaultAsync();
                    orgTrader.Name = model.Name;
                    if (model.VerifiedTrader)
                    {
                        orgTrader.VerifiedTrader = model.VerifiedTrader;
                        orgTrader.VerifiedLink = Guid.NewGuid().ToString();
                    }
                    _db.Entry(orgTrader).State = EntityState.Modified;
                    await _db.SaveChangesAsync();
                }
                return Ok(new BaseResponse(Constants.SC_SUCCESS, Constants.MSG_SUCCESS, model));
            }
            catch (Exception ex)
            {
                Log.Error("Error while updating trader.", ex);
                return StatusCode(StatusCodes.Status500InternalServerError,
                    new BaseResponse(Constants.SC_ISE, Constants.MSG_ISE, null));
            }
        }

        [HttpDelete]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                Trader orgTrader = await _db.Trader.Where(x => x.Id == id).FirstOrDefaultAsync();


                _db.Entry(orgTrader).State = EntityState.Deleted;
                await _db.SaveChangesAsync();
                return Ok(new BaseResponse(Constants.SC_SUCCESS, Constants.MSG_SUCCESS, null));
            }
            catch (Exception ex)
            {
                Log.Error("Error while deleting trader.", ex);
                return StatusCode(StatusCodes.Status500InternalServerError,
                    new BaseResponse(Constants.SC_ISE, Constants.MSG_ISE, null));
            }
        }
    }
}
