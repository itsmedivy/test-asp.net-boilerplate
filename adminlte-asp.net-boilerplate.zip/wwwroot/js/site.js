﻿// Write your JavaScript code.
(function ($) {
    // Your custom jQuery functions
    $(document).ready(function () {
        $.fn.myCustomFunction = function () {
            // Your implementation here
            alert('Hello from my custom function using jQuery!');
        };

        $.fn.GetCookie = function (cookieName) {
            let cookie = {};
            document.cookie.split(';').forEach(function (el) {
                let [key, value] = el.split('=');
                cookie[key.trim()] = value;
            })
            return cookie[cookieName];
        };

        //input validation
        $.fn.StrIsNullOrEmpty = function (str) {
            return !str || str.trim() === '';
        }
        $.fn.IsUndefined = function (variable) {
            return typeof variable === 'undefined';
        }
        //\. input validation

        $.fn.ArrayToCommaSep = function (array, lastSeprator = '&') {
            array = array.filter(function (item) {
                return item.trim() !== '';
            });
            var csv = array.join(', ');
            csv = csv.replace(/,([^,]*)$/, ' ' + lastSeprator + '$1');
            return csv;
        }

        //Data Converters
        $.fn.ToDecimal = function (value) {
            var dVal = parseFloat(value);
            dVal = isNaN(dVal) ? 0 : dVal;
            return dVal;
        };
        $.fn.StringDefault = function (value, defaultVal = "", prefix = "", suffix = "") {
            return $.trim(value) == "" ? defaultVal : prefix + value + suffix;
        };
        $.fn.Ellipses = function (value, length = 15) {
            var isEllipsed = false;
            var ellipsedStr = value;
            if (value.length > length) {
                isEllipsed = true;
                ellipsedStr = value.substr(0, length);
            }
            return { isEllipsed, ellipsedStr };
        };
        $.fn.EllipsesTooltip = function (value, length = 15) {
            var elp = $.fn.Ellipses(value, length);
            var span = "<span data-toggle='tooltip' title='" + value + "'>"
                + elp.ellipsedStr + (elp.isEllipsed ? "..." : "") + "</span>";
            return span;
        };

        $.fn.debounce = function (func, delay) {
            let timeoutId;
            return function () {
                const context = this;
                const args = arguments;

                clearTimeout(timeoutId);
                timeoutId = setTimeout(function () {
                    func.apply(context, args);
                }, delay);
            };
        };

        $.fn.Prefix = function (prefix, decValue) {
            return prefix + $.fn.ToDecimal(decValue).toFixed(3).replace(/\.?0+$/, "");
        };
        $.fn.Suffix = function (suffix, decValue) {
            return "" + $.fn.ToDecimal(decValue).toFixed(3).replace(/\.?0+$/, "") + suffix;
        };
        $.fn.Money = function (currency, amount) {
            return currency + $.fn.ToDecimal(amount).toFixed(3).replace(/\.?0+$/, "");
        };
        $.fn.Decimal3 = function (amount) {
            return '' + $.fn.ToDecimal(amount).toFixed(3).replace(/\.?0+$/, "");
        };
        // --Data Converters

        $.fn.InfoTooltip = function (text) {
            return "&nbsp;<i class='fa-solid fa-info-circle' data-toggle='tooltip' title='" + text + "'></i>";
        };
        $.fn.showAlert = function (container, cssClass, title, message) {
            $(container).empty();
            var icon = "";
            switch (cssClass) {
                case 'danger':
                    icon = '<i class="fa-solid fa-circle-xmark fa-shake"></i>';
                    break;
                case 'warning':
                    icon = '<i class="fa-solid fa-circle-radiation fa-spin"></i>';
                    break;
                case 'info':
                    icon = '<i class="fa-solid fa-circle-info fa-bounce"></i>';
                    break;
                case 'success':
                    icon = '<i class="fa-solid fa-circle-check fa-beat"></i>';
                    break;
                default:
                    icon = '<i class="fa-solid fa-shapes fa-flip"></i>';
                    break;
            }
            var _alert = $('<div class="alert alert-' + cssClass + ' alert-dismissible" role="alert">' +
                '   <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' +
                '   <h4>' + icon + '&nbsp;' + title + '</h4>' +
                '   ' + message +
                '</div>');
            $(container).append(_alert);
            setTimeout(function () {
                $(container).fadeOut(500, function () {
                    // Callback function executed after fadeOut completes
                    // Clear the contents of the div
                    $(this).empty();
                    $(this).show();
                });
            }, 4000);
        };
        $.fn.clearAlert = function (container) {
            $(container).empty();
        };


        $.fn.getRandomColor = function () {
            var letters = '0123456789ABCDEF';
            var color = '#';
            for (var i = 0; i < 6; i++) {
                color += letters[Math.floor(Math.random() * 16)];
            }
            return color;
        };

        // Function to create circular box with initials CircularName
        $.fn.CircularName = function (name) {
            var initials = name.match(/\b\w/g) || [];
            initials = ((initials.shift() || '') + (initials.pop() || '')).toUpperCase();
            var color = $.fn.getRandomColor();
            var circle = $('<div>').addClass('circle').css('background-color', color).text(initials);
            return circle;
        };

        // Add more functions as needed
    });
})(jQuery);